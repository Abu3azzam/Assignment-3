%ELEC 4700 - Assignment 3
%Name: Abdullah Abushaban
%Student#: 101089570
%Due date: March 20th, 2022 

%2. Use the Finite Difference Method in Assignment-2 to calculate the electric field.

L = 2; W = 3; Vo = 1;  nx = 100*L;  ny = 100*W; WB = 0.4;     
LB = 0.4;     

%sigma inside an outside of the box
sigin = 1;        
sigout = 1e-2;     

C = zeros(ny,nx);   %conductivity 

for j = 1:ny   for g = 1:nx
        
if(g >= nx*WB && g <= nx-nx*WB && (j >= ny-ny*LB || j <= ny*LB)) 
 C(j,g) = sigout;  
       
 else                                        
 %outside the box
  C(j,g) = sigin;
            
end
   
end

end

%   G matrix and B vector 

 G = sparse(nx*ny);  F = zeros(nx*ny,1);

for g = 1:nx
    
    for j = 1:ny
   
    n = j + (g - 1)*ny;     %node equation  
     
 %nodes at g and j
       
  nxm = j + (g - 2)*ny;     nxp = j + g*ny;
   nym = (j - 1) + (g - 1)*ny;   nyp = (j + 1) + (g - 1)*ny;

if(g == 1 || g == nx) 
            
            
G(n,n) = 1;     
   
elseif (j == 1)    %  bottom region 
            
     UY = (C(j,g)+C(j+1,g))/2;
     UX = (C(j,g)+C(j,g+1))/2;
     UXD = (C(j,g)+C(j,g-1))/2;
            
   G(n,n) = -(UY + UX + UXD);
     G(n,nyp) = UY;
        G(n,nxp) = UX;
         G(n,nxm) = UXD;
     
       
       
 elseif (j == ny)   %  upper region   
       
     YDYE = (C(j,g)+C(j-1,g))/2;  UDXE = (C(j,g)+C(j,g+1))/2;
     DDXE = (C(j,g)+C(j,g-1))/2;
              
     G(n,n) = -(YDYE + UDXE + DDXE);
     G(n,nym) = YDYE; G(n,nxp) = UDXE;
     G(n,nxm) = DDXE;
       
   else 
           
  UY = (C(j,g)+C(j+1,g))/2;   D_Y = (C(j,g)+C(j-1,g))/2;
  UX = (C(j,g)+C(j,g+1))/2;   UXD = (C(j,g)+C(j,g-1))/2;
            
            
   G(n,n) = -(UY + D_Y + UX + UXD);
   G(n,nyp) = UY; G(n,nym) = D_Y;
    G(n,nxp) = UX; G(n,nxm) = UXD;
            
            
  end
         
  end
 
end


for g = 1:nx   for j = 1:ny
       
        
 %Node Mapping calculation
  n = j + (g - 1)*ny;
       
        
   if (g == 1) 
                  
   F(n) = Vo;
            
            
        end    
        
end
    
end

% Utilizing  "GV = F "

V = G\F;


for g = 1:nx
    
    for j = 1:ny
        
        
   n = j + (g - 1)*ny;   % Node mapping 
        
   Vm(j,g) = V(n);
        
        
    end
end



%  Vx, V 
figure(5)
surf(Vm)

xlabel('L um')
ylabel('W um')
title({'Vx Vxy  '})

[Ex,Ey] = gradient(-Vm); 

% Plotting the Electric Field over the region

figure(6)
quiver(Ex,Ey)
xlabel('L um')
ylabel('W um')
title({'Electric Field (Region), '})



%Given:
T = 300;  
Cm = 9.10938356e-31; 
Cm = 0.26*Cm; 
q = -1.60217662e-19; 


% 200 nm x 100 nm
width = 200e-9;
len = 100e-9;

%  Vx  applied in x direction to be 0.1v

Vx = 0.1; 

% No change to the Vx  in Y direction
Vy = 0;


%  electron concentration given as
elecconc = 1e15*100^2;

% Thermal Velocity
K = 1.38064852e-23;  
Vt = sqrt(2*K*T/Cm);


elecpop = 10000;
elecnum = 100;

% Setting the Step Size
Time_Step = len/Vt/100;
iterations = 200;

% The scattering probabily is given by
scatter_p = 1 - exp(-Time_Step/0.2e-12);

%Using Maxewell-Boltzmann Distribution to Generate random velocities
Distr_MB = makedist('Normal', 0, sqrt(K*T/Cm));

ap = 0;

%  scattering probabily given by
scatter_p = 1 - exp(-Time_Step/0.2e-12);


% Electric Field 
Electric_Field = Vx/width; 
fprintf(' The Electric field experienced by the electrons is %i\n',Electric_Field);

%  Force
Force = Electric_Field*q;
fprintf(' The Force experienced by the electrons is %i\n',Force);

%  Accelaration 
Accelaration = Force/Cm; 
fprintf(' The accelaration of the electrons is %i\n',Accelaration);

% Electric Field and Force in Y direction  
ElecFieldY = Vy/len
ForceY = q*ElecFieldY


%  velocity at each time step 
DX = Force*Time_Step/Cm;    DY = ForceY*Time_Step/Cm;
DX = DX.*ones(elecpop,1);    DY = DY.*ones(elecpop,1);


% Specular conditions  "Top & Bottom" 
Specupper = 0;
Speclower = 0;

posisionx = zeros(elecpop, 4);



%Keeping track of trajectories
path = zeros(iterations, elecnum*2);


%Recording the temeperatures
Temperature = zeros(iterations,1);


st_size = 1e-9;
boxes = st_size.*[80 120 0 40; 80 120 60 100];
spec_boxes = [0 1];


%Setting up x and positions
for ni = 1:elecpop
    
    thet = rand*2*pi;
    posisionx(ni,:) = [width*rand len*rand random(Distr_MB) random(Distr_MB)];
    
end



%  Monte Carlo Model

for ni = 1:iterations                
    
    
    %Utilzing the velocities of the electrons to determine positions
    posisionx(:,2) = posisionx(:,2) + DX;
    posisionx(:,3) = posisionx(:,3) + DY;
    
    
     %Boundary Conditions 
    posisionx(:,1:2) = posisionx(:,1:2) + Time_Step.*posisionx(:,2:3);

    nk = posisionx(:,1) > width;
    posisionx(nk,1) = posisionx(nk,1) - width;
    
    nk = posisionx(:,1) < 0;
    posisionx(nk,1) = posisionx(nk,1) + width;
    
    nk = posisionx(:,2) > len;

    
%  Region Boundary "top"
  if(Specupper)                                  
        
    posisionx(nk,2) = 2*len - posisionx(nk,2);
   posisionx(nk,4) = -posisionx(nk,4);
              
    else 
        
  posisionx(nk,2) = 100e-9;                                    
   Z = sqrt(posisionx(nk,3).^2 + posisionx(nk,4).^2);
        
   thet = rand([sum(nk),1])*2*pi;
   posisionx(nk,2) = Z.*cos(thet);
   posisionx(nk,3) = -abs(Z.*sin(thet));
            
    end
      
    nk = posisionx(:,2) < 0;
    
    
  % the region boundary "botttom"
    if(Speclower)
                                                          
    posisionx(nk,2) = -posisionx(nk,2);
    posisionx(nk,4) = -posisionx(nk,4);
        
      else  
                                                           
  posisionx(nk,2) = 0;                                       
 Z = sqrt(posisionx(nk,3).^2 + posisionx(nk,4).^2);
               
  thet = rand([sum(nk),1])*2*pi;
  posisionx(nk,3) = Z.*cos(thet);
   posisionx(nk,4) = abs(Z.*sin(thet));
             
    end
    
    % Checking for particle if they moved into boxes 
    
    for nk= 1:elecnum
            
        
% collision location:
        
 while(bottle ~= 0)
            
   X_dis = 0;        % X position       
   X_New = 0;
                     
   if(posisionx(nk,3) > 0)
   X_dis = posisionx(nk,1) - boxes(bottle,1);
   X_New = boxes(bottle,1);
                
     else
                
   X_dis = boxes(bottle,2) - posisionx(nk,1);
   X_New = boxes(bottle,2);
                
                
   end

   Y_dis = 0;             % Y position
   Y_New = 0;
            
   if(posisionx(nk,4) > 0)
                
   Y_dis = posisionx(nk,2) - boxes(bottle, 3);
   Y_New = boxes(bottle, 3);
                
    else
                
   Y_dis = boxes(bottle, 4) - posisionx(nk,2);
   Y_New = boxes(bottle, 4);
                
    end

    if(X_dis < Y_dis)
                
   posisionx(nk,1) = X_New;
                
    if(~spec_boxes(bottle))
    sn = -sign(posisionx(nk,3));
    Z = sqrt(posisionx(nk,3).^2 + posisionx(nk,4).^2);
                    
       thet = rand()*2*pi;
       posisionx(nk,3) = sn.*abs(Z.*cos(thet));
       posisionx(nk,4) = Z.*sin(thet);            
                    
   else 
                    
  %  condition specular 
                    
  posisionx(nk,3) = -posisionx(nk,3);
                    
     end
                
     else
                
                
    posisionx(nk,2) = Y_New;
                if(~spec_boxes(bottle))
                    
    sn = -sign(posisionx(nk,4));
    Z = sqrt(posisionx(nk,3).^2 + posisionx(nk,4).^2);
    thet = rand()*2*pi;
                    
     posisionx(nk,3) = Z.*cos(thet);
     posisionx(nk,4) = sn.*abs(Z.*sin(thet));
                    
     else 
                     
     posisionx(nk,4) = -posisionx(nk,4);
                    
     end
     end
            
     bottle = box(posisionx(nk,1:2), boxes);
            
            
   end
        
   end
    
     nk = rand(elecpop, 1) < scatter_p;           
     posisionx(nk,3:4) = random(Distr_MB, [sum(nk),2]);           
    
    
  % Temperature of the electrons
    Temperature(ni) = (sum(posisionx(:,3).^2) + sum(posisionx(:,4).^2))*Cm/K/2/elecpop;           
    for nk=1:elecnum
       
        path(ni, (2*nk):(2*nk+1)) = posisionx(nk, 1:2);       
    end
  
    % electron trajectories plot
    
    if(ap && mod(ni,8) == 0)
     figure(7);
     hold off;
     plot(posisionx(1:elecnum,1), posisionx(1:elecnum,2), '0');       
     hold on;
        
        
   for nk=1:size(boxes,1)        
            
   plot([boxes(nk, 1) boxes(nk, 1) boxes(nk, 2) boxes(nk, 2) boxes(nk, 1)],...
   [boxes(nk, 3) boxes(nk, 4) boxes(nk, 4) boxes(nk, 3) boxes(nk, 3)], 'k-');
          
          end
        
        title('Electron Traj '); 
        xlabel('X )');
        ylabel('Y ');
        pause(0.05);
        
    end
    
end



