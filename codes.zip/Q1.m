
%ELEC 4700 - Assignment 3
%Name: Abdullah Abushaban
%Student #: 101089570
%Due date: March 20th, 2022 


%1. Start with your Monte-Carlo simulator from Assignment-1 without the bottle-neck:

set(0,'DefaultFigureWindowStyle','docked')
clear all;


%Given: 
T = 300;  %Unit: Kelvin 
m = 9.10938356e-31;    Cm = 0.26*m;    q = -1.60217662e-19; 
width = 200e-9;    len = 100e-9;
%0.1 V applied across the x dimension of the semiconductor:
Vx = 0.1;   Vy = 0;
%assumption for electron concentration given:
elecconc = 1e15*100^2;
% thermal Velocity
K = 1.38064852e-23;   Vt = sqrt(2*K*T/Cm);
elecp = 30000;  elecn = 50;
Time_Step = len/Vt/100;  iter = 200;
%  scattering probabily is:
scatter_p = 1 - exp(-Time_Step/0.2e-12);
% Maxewell-Boltzmann Distribution:
Distr_MB = makedist('Normal',0, sqrt(K*T/Cm));
ap = 0; %animation plot 
scatter_p = 1 - exp(-Time_Step/0.2e-12);
Xr = 2e-7;  Yr = 1e-7;
EField = Vx / Xr;  EF = q * EField;
AccEle = EF/Cm;
% Now, determining the Electric Field: 
Electric_Field = Vx/width; 
fprintf(' The Electric field tested by the electrons is %i\n',Electric_Field);

Force = Electric_Field*q;
Accelaration = Force/Cm; 
ElecFieldY = Vy/len
ForceY = q*ElecFieldY
DX = Force*Time_Step/Cm;  %partical velocity 
DY = ForceY*Time_Step/Cm; %partical velocity 
DX = DX.*ones(elecp,1);   DY = DY.*ones(elecp,1);   
%  Specular upper and lower boundary conditions:
Specupper = 0;
Speclower = 0;
posx = zeros(elecp, 4);

for ni = 1:elecp
    theta = rand*2*pi;
        posx(ni,:) = [width*rand len*rand random(Distr_MB) random(Distr_MB)];
    end
%path of the particle tracking:
path = zeros(iter, elecn*2);
% temprature: 
Temp = zeros(iter,1);
%current density:
CurrDensity = zeros(iter,2);
% Electrons path:
figure(1);
plot([],[]);
title('Electrons path, '); 
xlabel('X ');
ylabel('Y');
%current x time:
figure(2);
current_plot =  animatedline('Color','b','LineWidth',5); 
title('Current x Time, ');
xlabel('Time');
ylabel('Current');
grid on;
%  Monte Carlo Model Simulation:

for ni = 1:iter 
% determine positions by Utilzing the velocities: 
    posx(:,3) = posx(:,3) + DX; posx(:,4) = posx(:,4) + DY;
% Boundary Conditions: 
    posx(:,1:2) = posx(:,1:2) + Time_Step.*posx(:,3:4);
nk = posx(:,1) > width;
    posx(nk,1) = posx(nk,1) - width;
nk = posx(:,1) < 0;
    posx(nk,1) = posx(nk,1) + width;
nk = posx(:,2) > len;
%  Region Boundary "Upper":
    if(Specupper)    
        posx(nk,2) = 2*len - posx(nk,2);
        posx(nk,4) = -posx(nk,4);
        else 
    posx(nk,2) = 100e-9;      
        Z = sqrt(posx(nk,3).^2 + posx(nk,4).^2);
      theta = rand([sum(nk),1])*2*pi;
        posx(nk,3) = Z.*cos(theta);
        posx(nk,4) = -abs(Z.*sin(theta));
      end
  nk = posx(:,2) < 0;
%  region boundary "lower":
      if(Speclower)
        posx(nk,2) = -posx(nk,2);
        posx(nk,4) = -posx(nk,4);
        else  
     posx(nk,2) = 0;                                       
        Z = sqrt(posx(nk,3).^2 + posx(nk,4).^2);
      theta = rand([sum(nk),1])*2*pi;
        posx(nk,3) = Z.*cos(theta);
        posx(nk,4) = abs(Z.*sin(theta));
       end
   nk = rand(elecp, 1) < scatter_p;           
       posx(nk,3:4) = random(Distr_MB, [sum(nk),2]); 
% Temperature of the electrons:
    Temp(ni) = (sum(posx(:,3).^2) + sum(posx(:,4).^2))*Cm/K/2/elecp;           
for nk=1:elecn
% saving the positions on the path:
        path(ni, (2*nk):(2*nk+1)) = posx(nk, 1:2);
        end
  CurrDensity(ni, 1) = q.*elecconc.*mean(posx(:,3));           
    CurrDensity(ni, 2) = q.*elecconc.*mean(posx(:,4));
addpoints(current_plot, Time_Step.*ni, CurrDensity(ni,1));           
% Plotting the electron trajectories and temeperature variance
    if(ap && mod(ni,8) == 0)
        %  updates for every 8 iterations
        figure(1);
           hold off;
        plot(posx(1:elecn,1), posx(1:elecn,2), 'x');       
           hold on;
        title(' Electrons path, '); 
        xlabel('X ');
        ylabel('Y');
           pause(0.05);
        end
end
%Final plotting for trajectories:

figure(1);
title('Electrons path, ');
xlabel('X ');
ylabel('Y');
  grid on;
  hold on;
%Saving  trajectory after completion: 
for ni=1:elecn
    plot(path(:,ni*2), path(:,ni*2+1), '+');
   end
%  Density Map plot: 
elecconc = hist3(posx(:,1:2),[200 100])';
% Using bins from the historgram in order to determine the Temperature and Density map: 
histbins = 8;    

[xelec, yelec] = meshgrid(round(-histbins/2):round(histbins/2), round(-histbins/2):round(histbins/2));
L=exp(-xelec.^2/(2*1^2)-yelec.^2/(2*1^2));
L=L./sum(L(:));

figure(3);
elecconc = conv2(elecconc,L,'same');
elecconc = elecconc/(len./size(elecconc,1)*width./size(elecconc,2));

surf(conv2(elecconc,L,'same'));
title('Electrons Den, ');
   xlabel('X');
    ylabel('Y');
% Map of temperature:

XTemp = zeros(ceil(width/1e-9),ceil(len/1e-9));
  YTemp = zeros(ceil(width/1e-9),ceil(len/1e-9));
     TotalTemp = zeros(ceil(width/1e-9),ceil(len/1e-9));


for ni=1:elecp
   xelec = floor(posx(ni,1));
    yelec = floor(posx(ni,2));   
  if(xelec==0)
        xelec = 1;end
    if(yelec==0) 
        yelec= 1;end
    YTemp(xelec,yelec) = YTemp(xelec,yelec) + posx(ni,3)^2;
    XTemp(xelec,yelec) = XTemp(xelec,yelec) + posx(ni,4)^2;
    TotalTemp(xelec,yelec) = TotalTemp(xelec,yelec) + 1;
   end
% Temperature calculation:  

temp = (XTemp + YTemp)*Cm/K/2/TotalTemp;
temp= temp*1;  
% Temperature plot:
histbins = 8;
[xelec , yelec] = meshgrid(round(-histbins/2):round(histbins/2), round(-histbins/2):round(histbins/2));
L=exp(-xelec.^2/(2*1^2)-yelec.^2/(2*1^2));
L=L/sum(L(:));


figure(4);
imagesc(conv2(temp,L,'same'));  
view(0,90)
title('Tem Map, ');
xlabel('X');
ylabel('Y');